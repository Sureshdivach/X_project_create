import "./bookmark.scss"
import { HiOutlineDotsHorizontal } from "react-icons/hi";
import { IoSearchSharp } from "react-icons/io5";
const BookMark=()=>{
    return(
        <div className="Book_main_cont" >
            <div className="uper_book_cont">
              <div><h3>Bookmarks</h3>
              <p>@SURESHK792</p></div> 
              <HiOutlineDotsHorizontal/> 
            </div>
            <div>
                <IoSearchSharp/>
                <input type='text'> </input>
            </div>
           
        </div>
    )
}
export default BookMark;