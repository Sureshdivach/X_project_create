import "./ment.scss"
const MentData=()=>{
    return(
        <div className="main_mention_cont">
            <h1>Nothing to see here- <br/> yet</h1>
            <p>when somone mentions you, you'll fint it here.</p>
        </div>
    )
}
export default MentData;